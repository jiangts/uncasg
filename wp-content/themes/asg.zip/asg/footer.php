<!-- Footer area ================== -->
        <footer id="footer">


            <!-- Content ================= -->
            <section class="content">

                <div class="container">
                    <div class="row">

                        <div class="span3 widget">
                        </div>

                        <div class="span3 widget">	
                        </div>

                        <div class="span3 widget">
                        </div>
                        <div class="span3 widget">
                        </div>

                    </div>
                </div><!-- /container -->

            </section>


            <!-- Footer bottom ================= -->
            <section class="bottom">

                <div class="container">
                    <div class="row">

                        <p class="span12 copyright">&copy; 2013 Atkins TSA. All Rights Reserved.</p>

                    </div>
                </div><!-- /container -->

            </section>
            
        </footer><!-- /footer -->




		<!--INIT IMAGE SLIDER ON INDEX.PHP-->
		<script>
    $(function() {
      $('#slides').slidesjs({
        width: 940,
        height: 528,
        play: {
          active: true,
          auto: true,
          interval: 4000,
          swap: true
        }
      });
    });
  </script>
	
	</body>
</html>